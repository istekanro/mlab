self.addEventListener('install',event =>
 console.log('sw is installed',event));

 self.addEventListener('activate',event =>
 console.log('sw is activated',event));


 self.addEventListener('fetch', function(event) {
     console.log('sw is fetched',event);
    event.respondWith(
      caches.match(event.request).then(function(response) {
        return response || fetch(event.request);
      })
    );
   });  