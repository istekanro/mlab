package com.example.Program3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    ConstraintLayout cs;
    Button button;
    int show=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cs=findViewById(R.id.cs);
        button=findViewById(R.id.button);
        Fragment1 f1=new Fragment1();
        Fragment2 f2=new Fragment2();
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft= fm.beginTransaction();
        ft.add(R.id.cs,f1);
        ft.commit();
        show=1;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft= fm.beginTransaction();
                if(show==1){
                    ft.replace(R.id.cs,f2);
                    ft.commit();
                    show=2;
                }
                else{
                    ft.replace(R.id.cs,f1);
                    ft.commit();
                    show=1;
                }
            }
        });

    }
}