package com.example.program5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button Login,Register;
    EditText uName,pswd;
    DbHandler db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Login=findViewById(R.id.btn1);
        Register=findViewById(R.id.btn2);
        uName=findViewById(R.id.et1);
        pswd=findViewById(R.id.et2);
        db=new DbHandler(MainActivity.this);
        Register.setEnabled(false);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=uName.getText().toString();
                String password=pswd.getText().toString();
                int id= checkUser(new User(username,password));

                if(id==-1)
                {
                    Toast.makeText(MainActivity.this,"User Does Not Exist",Toast.LENGTH_SHORT).show();
                    Register.setEnabled(true);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Username "+username+ " exist",Toast.LENGTH_SHORT).show();
                    uName.setText(null);
                    pswd.setText(null);
                    Intent i = new Intent(MainActivity.this, SecondActivity.class);
                    startActivity(i);
                }


            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=uName.getText().toString();
                String password=pswd.getText().toString();
                int id= checkUser(new User(username,password));

                if(id==-1)
                {
                    db.addUser(new User(username,password));
                    Toast.makeText(MainActivity.this,"Registered Successfully",Toast.LENGTH_SHORT).show();
                    uName.setText(null);
                    pswd.setText(null);
                    Register.setEnabled(false);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Username "+username+ " exist",Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
    public int checkUser(User user)
    {
        return db.checkUser(user);
    }
}