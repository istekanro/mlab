package com.example.program2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton i1;
    Switch s1;
    ConstraintLayout cs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        i1 = findViewById(R.id.i1);
        s1 = findViewById(R.id.s1);
        cs = findViewById(R.id.cs);

        DatePicker datePicker = new DatePicker(this);
        cs.addView(datePicker);

        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    i1.setEnabled(true);
                    Toast.makeText(getApplicationContext(), "Switch is Enabled", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    i1.setEnabled(false);
                    Toast.makeText(getApplicationContext(), "Switch is disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}